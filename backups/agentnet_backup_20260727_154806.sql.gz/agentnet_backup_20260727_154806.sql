--
-- PostgreSQL database dump
--

\restrict PVT2X2fEdwa76gt2R9yZ0KEZM5bQj7SeeZBLAWcqjtmRZthHQnQfAcWL16Sbk0a

-- Dumped from database version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.permissions DROP CONSTRAINT IF EXISTS permissions_agent_id_fkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_sender_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_conversation_id_fkey;
ALTER TABLE IF EXISTS ONLY public.conversations DROP CONSTRAINT IF EXISTS conversations_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.conversation_members DROP CONSTRAINT IF EXISTS conversation_members_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.conversation_members DROP CONSTRAINT IF EXISTS conversation_members_conversation_id_fkey;
ALTER TABLE IF EXISTS ONLY public.contacts DROP CONSTRAINT IF EXISTS contacts_requester_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.contacts DROP CONSTRAINT IF EXISTS contacts_addressee_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS audit_logs_owner_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.agents DROP CONSTRAINT IF EXISTS agents_owner_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.agent_events DROP CONSTRAINT IF EXISTS agent_events_agent_id_fkey;
ALTER TABLE IF EXISTS ONLY public.agent_credentials DROP CONSTRAINT IF EXISTS agent_credentials_agent_id_fkey;
ALTER TABLE IF EXISTS ONLY public.agent_conversation_acls DROP CONSTRAINT IF EXISTS agent_conversation_acls_granted_by_fkey;
ALTER TABLE IF EXISTS ONLY public.agent_conversation_acls DROP CONSTRAINT IF EXISTS agent_conversation_acls_conversation_id_fkey;
ALTER TABLE IF EXISTS ONLY public.agent_conversation_acls DROP CONSTRAINT IF EXISTS agent_conversation_acls_agent_id_fkey;
DROP INDEX IF EXISTS public.ix_users_email;
DROP INDEX IF EXISTS public.ix_permissions_agent_id;
DROP INDEX IF EXISTS public.ix_messages_conversation_id;
DROP INDEX IF EXISTS public.ix_messages_client_message_id;
DROP INDEX IF EXISTS public.ix_conversation_members_user_id;
DROP INDEX IF EXISTS public.ix_conversation_members_conversation_id;
DROP INDEX IF EXISTS public.ix_contacts_requester_user_id;
DROP INDEX IF EXISTS public.ix_contacts_addressee_user_id;
DROP INDEX IF EXISTS public.ix_audit_logs_owner_user_id;
DROP INDEX IF EXISTS public.ix_agents_owner_user_id;
DROP INDEX IF EXISTS public.ix_agents_handle;
DROP INDEX IF EXISTS public.ix_agent_events_agent_id;
DROP INDEX IF EXISTS public.ix_agent_credentials_prefix;
DROP INDEX IF EXISTS public.ix_agent_credentials_agent_id;
DROP INDEX IF EXISTS public.ix_agent_conversation_acls_conversation_id;
DROP INDEX IF EXISTS public.ix_agent_conversation_acls_agent_id;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.permissions DROP CONSTRAINT IF EXISTS permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_pkey;
ALTER TABLE IF EXISTS ONLY public.conversations DROP CONSTRAINT IF EXISTS conversations_pkey;
ALTER TABLE IF EXISTS ONLY public.conversation_members DROP CONSTRAINT IF EXISTS conversation_members_pkey;
ALTER TABLE IF EXISTS ONLY public.contacts DROP CONSTRAINT IF EXISTS contacts_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS audit_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.agents DROP CONSTRAINT IF EXISTS agents_pkey;
ALTER TABLE IF EXISTS ONLY public.agent_events DROP CONSTRAINT IF EXISTS agent_events_pkey;
ALTER TABLE IF EXISTS ONLY public.agent_credentials DROP CONSTRAINT IF EXISTS agent_credentials_pkey;
ALTER TABLE IF EXISTS ONLY public.agent_conversation_acls DROP CONSTRAINT IF EXISTS agent_conversation_acls_pkey;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.permissions;
DROP TABLE IF EXISTS public.messages;
DROP TABLE IF EXISTS public.conversations;
DROP TABLE IF EXISTS public.conversation_members;
DROP TABLE IF EXISTS public.contacts;
DROP TABLE IF EXISTS public.audit_logs;
DROP TABLE IF EXISTS public.agents;
DROP TABLE IF EXISTS public.agent_events;
DROP TABLE IF EXISTS public.agent_credentials;
DROP TABLE IF EXISTS public.agent_conversation_acls;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agent_conversation_acls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_conversation_acls (
    id character varying(64) NOT NULL,
    conversation_id character varying(64) NOT NULL,
    agent_id character varying(64) NOT NULL,
    permission character varying(20) NOT NULL,
    granted_by character varying(64) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_credentials (
    id character varying(64) NOT NULL,
    agent_id character varying(64) NOT NULL,
    name character varying(100) NOT NULL,
    secret_hash character varying(255) NOT NULL,
    prefix character varying(16) NOT NULL,
    scopes text NOT NULL,
    expires_at timestamp with time zone,
    revoked_at timestamp with time zone,
    last_used_at timestamp with time zone,
    status character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_events (
    id character varying(64) NOT NULL,
    agent_id character varying(64) NOT NULL,
    event_type character varying(50) NOT NULL,
    payload text NOT NULL,
    status character varying(20) NOT NULL,
    attempts integer NOT NULL,
    available_at timestamp with time zone DEFAULT now() NOT NULL,
    acked_at timestamp with time zone,
    max_attempts integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agents (
    id character varying(64) NOT NULL,
    owner_user_id character varying(64) NOT NULL,
    handle character varying(50) NOT NULL,
    display_name character varying(100) NOT NULL,
    status character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id character varying(64) NOT NULL,
    owner_user_id character varying(64) NOT NULL,
    agent_id character varying(64),
    action character varying(50) NOT NULL,
    target_type character varying(50) NOT NULL,
    target_id character varying(64) NOT NULL,
    result character varying(20) NOT NULL,
    audit_metadata text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contacts (
    id character varying(64) NOT NULL,
    requester_user_id character varying(64) NOT NULL,
    addressee_user_id character varying(64) NOT NULL,
    status character varying(20) NOT NULL,
    requested_at timestamp with time zone DEFAULT now() NOT NULL,
    responded_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: conversation_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conversation_members (
    id character varying(64) NOT NULL,
    conversation_id character varying(64) NOT NULL,
    user_id character varying(64) NOT NULL,
    role character varying(20) NOT NULL,
    joined_at timestamp with time zone DEFAULT now() NOT NULL,
    left_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: conversations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conversations (
    id character varying(64) NOT NULL,
    type character varying(20) NOT NULL,
    created_by character varying(64) NOT NULL,
    title character varying(200) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages (
    id character varying(64) NOT NULL,
    conversation_id character varying(64) NOT NULL,
    sender_user_id character varying(64) NOT NULL,
    sender_agent_id character varying(64),
    actor_type character varying(10) NOT NULL,
    content_type character varying(20) NOT NULL,
    body text NOT NULL,
    client_message_id character varying(128),
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permissions (
    id character varying(64) NOT NULL,
    agent_id character varying(64) NOT NULL,
    scope character varying(64) NOT NULL,
    effect character varying(10) NOT NULL,
    resource_type character varying(50) NOT NULL,
    resource_id character varying(64) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id character varying(64) NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    display_name character varying(100) NOT NULL,
    status character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Data for Name: agent_conversation_acls; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_conversation_acls (id, conversation_id, agent_id, permission, granted_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agent_credentials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_credentials (id, agent_id, name, secret_hash, prefix, scopes, expires_at, revoked_at, last_used_at, status, created_at, updated_at) FROM stdin;
20260727072215545113_a1673211a021	20260727072215383208_2307de1cedf3	hermes-test	$argon2id$v=19$m=65536,t=3,p=4$3ptzzjnnvHdOKYXQOifEmA$fYCwb1Keb6qANuz6kOudYuWv4jyFXUND0r3qZzy4s3c	agn_X6aXc3gx	profile:read,messages:read,messages:send	\N	2026-07-27 15:22:15.912791+08	2026-07-27 15:22:15.709986+08	revoked	2026-07-27 15:22:15.430152+08	2026-07-27 15:22:15.91122+08
20260727072216023497_70d3a9ac2975	20260727072215383208_2307de1cedf3	hermes-test-rotated	$argon2id$v=19$m=65536,t=3,p=4$HsPYW0tJybnX2vs/Z4zxPg$s4TESEn95KSCpT6wF8xufsGkQwhl+53vRoYU3chuACM	agn_iqFsVOoY	profile:read,messages:read,messages:send	\N	\N	2026-07-27 15:22:16.166954+08	active	2026-07-27 15:22:15.91122+08	2026-07-27 15:22:16.05447+08
20260727072243269728_adde30267459	20260727072243155907_6ccd63bf9580	verify-key	$argon2id$v=19$m=65536,t=3,p=4$2DsH4FxLiRECACBEiDEGoA$w1E55A0sYOIFYG6rfMrmd04YgdCrKipfld2WQjuZp0M	agn_1gF92dZw	profile:read,messages:read,messages:send	\N	2026-07-27 15:22:43.565948+08	2026-07-27 15:22:43.385667+08	revoked	2026-07-27 15:22:43.164055+08	2026-07-27 15:22:43.564504+08
20260727072243679523_7000be99c03a	20260727072243155907_6ccd63bf9580	verify-key-rotated	$argon2id$v=19$m=65536,t=3,p=4$aI2xNsaYs9YaI0SodU6pVQ$2JzxSsnu53l16ZrYpMaDZItcKWdCZU1S5VkB6ZhAVMk	agn_9ys5Ca_w	profile:read,messages:read,messages:send	\N	\N	2026-07-27 15:22:43.794322+08	active	2026-07-27 15:22:43.564504+08	2026-07-27 15:22:43.682839+08
20260727074335988215_40d1ae0abb94	20260727074335844815_f571a329dea1	sp3-key	$argon2id$v=19$m=65536,t=3,p=4$LYVwjrH2PkfIeU/pvbf2ng$gfcf3D2acYrPbO/LHMkMl9O/tBqofqH7ntXV6laTN1A	agn_tz88lvfA	profile:read,messages:read,messages:send	\N	\N	2026-07-27 15:43:36.252147+08	active	2026-07-27 15:43:35.878526+08	2026-07-27 15:43:36.139831+08
20260727074405965722_cc87bd1a29d9	20260727074405829140_2acf5c4eec4d	ev-key	$argon2id$v=19$m=65536,t=3,p=4$tZYyptTau9daqzWGcK7VWg$wjbTW/CAmDK0JCg/brQeCOkBTt/ET3b7tVjIMLZGm1s	agn_p5FWtKYn	profile:read,messages:read,messages:send	\N	\N	\N	active	2026-07-27 15:44:05.858924+08	2026-07-27 15:44:05.858924+08
\.


--
-- Data for Name: agent_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_events (id, agent_id, event_type, payload, status, attempts, available_at, acked_at, max_attempts, created_at, updated_at) FROM stdin;
20260727074336119836_6ab63a54f2f4	20260727074335844815_f571a329dea1	message.received	{"message_id": "20260727074336112237_ea24aeb1f737", "conversation_id": "20260727074336085259_09db67a76e5e", "sender_user_id": "20260727074335638252_bb8e3fb643a7", "body": "Hello from Alice", "actor_type": "human"}	pending	0	2026-07-27 15:43:36.104812+08	\N	5	2026-07-27 15:43:36.104812+08	2026-07-27 15:43:36.104812+08
20260727074406080935_1bc10fae0f95	20260727074405829140_2acf5c4eec4d	message.received	{"message_id": "20260727074406074949_b748f652bcd5", "conversation_id": "20260727074406052340_f5c0d66b157f", "sender_user_id": "20260727074405596525_b455b43f50ea", "body": "Hello from human", "actor_type": "human"}	delivered	1	2026-07-27 15:44:06.069213+08	\N	5	2026-07-27 15:44:06.069213+08	2026-07-27 15:44:06.236845+08
\.


--
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agents (id, owner_user_id, handle, display_name, status, created_at, updated_at) FROM stdin;
20260727072215383208_2307de1cedf3	20260727072215363984_185b1e7c1911	alpha	Alpha Agent	active	2026-07-27 15:22:15.378776+08	2026-07-27 15:22:15.378776+08
20260727072243155907_6ccd63bf9580	20260727072243123281_baf52941f213	verify-agent	Verify Agent	active	2026-07-27 15:22:43.15422+08	2026-07-27 15:22:43.15422+08
20260727073213354653_57ee34669d79	20260727073212769443_120e8210a435	alice-agent	Alice Agent	active	2026-07-27 15:32:13.325963+08	2026-07-27 15:32:13.325963+08
20260727073213414256_7fdba33e4296	20260727073213137096_a36e3ec76ace	bob-agent	Bob Agent	active	2026-07-27 15:32:13.409143+08	2026-07-27 15:32:13.409143+08
20260727074335844815_f571a329dea1	20260727074335793260_e1b9c7b86c93	sp3-agent-b	SP3 Agent B	active	2026-07-27 15:43:35.840391+08	2026-07-27 15:43:35.840391+08
20260727074405829140_2acf5c4eec4d	20260727074405775883_69f6ee1765da	ev-agent	EventAgent	active	2026-07-27 15:44:05.824962+08	2026-07-27 15:44:05.824962+08
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, owner_user_id, agent_id, action, target_type, target_id, result, audit_metadata, created_at, updated_at) FROM stdin;
20260727074336123229_0d75a1763980	20260727074335638252_bb8e3fb643a7	\N	human.message.send	message	20260727074336112237_ea24aeb1f737	success	{"conversation_id": "20260727074336085259_09db67a76e5e", "preview": "Hello from Alice"}	2026-07-27 15:43:36.104812+08	2026-07-27 15:43:36.104812+08
20260727074336696729_ad7f84e1bf67	20260727074335793260_e1b9c7b86c93	20260727074335844815_f571a329dea1	agent.message.send	message	20260727074336692075_318fa579b5c6	success	{"conversation_id": "20260727074336085259_09db67a76e5e", "preview": "Reply via agent! \\ud83e\\udd16"}	2026-07-27 15:43:36.687962+08	2026-07-27 15:43:36.687962+08
20260727074406083403_fbbf010980b5	20260727074405596525_b455b43f50ea	\N	human.message.send	message	20260727074406074949_b748f652bcd5	success	{"conversation_id": "20260727074406052340_f5c0d66b157f", "preview": "Hello from human"}	2026-07-27 15:44:06.069213+08	2026-07-27 15:44:06.069213+08
\.


--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contacts (id, requester_user_id, addressee_user_id, status, requested_at, responded_at, created_at, updated_at) FROM stdin;
20260727073444429201_fc9e1e5205c6	20260727073444399084_52737717874f	20260727073444252237_07de0b96f196	accepted	2026-07-27 15:34:44.420403+08	2026-07-27 15:34:44.452785+08	2026-07-27 15:34:44.420403+08	2026-07-27 15:34:44.449646+08
20260727074336036492_186c9df83d86	20260727074335793260_e1b9c7b86c93	20260727074335638252_bb8e3fb643a7	accepted	2026-07-27 15:43:36.031276+08	2026-07-27 15:43:36.052713+08	2026-07-27 15:43:36.031276+08	2026-07-27 15:43:36.05029+08
20260727074406005883_f4422b66b338	20260727074405775883_69f6ee1765da	20260727074405596525_b455b43f50ea	accepted	2026-07-27 15:44:05.997864+08	2026-07-27 15:44:06.025888+08	2026-07-27 15:44:05.997864+08	2026-07-27 15:44:06.02362+08
\.


--
-- Data for Name: conversation_members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conversation_members (id, conversation_id, user_id, role, joined_at, left_at, created_at, updated_at) FROM stdin;
20260727073444488987_e296128a5eb1	20260727073444485987_b3282d39a33d	20260727073444252237_07de0b96f196	member	2026-07-27 15:34:44.471565+08	\N	2026-07-27 15:34:44.471565+08	2026-07-27 15:34:44.471565+08
20260727073444489032_63f367461111	20260727073444485987_b3282d39a33d	20260727073444399084_52737717874f	member	2026-07-27 15:34:44.471565+08	\N	2026-07-27 15:34:44.471565+08	2026-07-27 15:34:44.471565+08
20260727074336087306_be90b9391267	20260727074336085259_09db67a76e5e	20260727074335638252_bb8e3fb643a7	member	2026-07-27 15:43:36.072738+08	\N	2026-07-27 15:43:36.072738+08	2026-07-27 15:43:36.072738+08
20260727074336087335_5ab72f37d610	20260727074336085259_09db67a76e5e	20260727074335793260_e1b9c7b86c93	member	2026-07-27 15:43:36.072738+08	\N	2026-07-27 15:43:36.072738+08	2026-07-27 15:43:36.072738+08
20260727074406054474_ffeaa5a30a68	20260727074406052340_f5c0d66b157f	20260727074405596525_b455b43f50ea	member	2026-07-27 15:44:06.042834+08	\N	2026-07-27 15:44:06.042834+08	2026-07-27 15:44:06.042834+08
20260727074406054509_df844625dabc	20260727074406052340_f5c0d66b157f	20260727074405775883_69f6ee1765da	member	2026-07-27 15:44:06.042834+08	\N	2026-07-27 15:44:06.042834+08	2026-07-27 15:44:06.042834+08
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conversations (id, type, created_by, title, created_at, updated_at) FROM stdin;
20260727073444485987_b3282d39a33d	direct	20260727073444252237_07de0b96f196		2026-07-27 15:34:44.471565+08	2026-07-27 15:34:44.471565+08
20260727074336085259_09db67a76e5e	direct	20260727074335638252_bb8e3fb643a7		2026-07-27 15:43:36.072738+08	2026-07-27 15:43:36.072738+08
20260727074406052340_f5c0d66b157f	direct	20260727074405596525_b455b43f50ea		2026-07-27 15:44:06.042834+08	2026-07-27 15:44:06.042834+08
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.messages (id, conversation_id, sender_user_id, sender_agent_id, actor_type, content_type, body, client_message_id, deleted_at, created_at, updated_at) FROM stdin;
20260727073444519203_5a3e42fcccc3	20260727073444485987_b3282d39a33d	20260727073444252237_07de0b96f196	\N	human	text	Hello from A	20260727073444485987_b3282d39a33d-m1	\N	2026-07-27 15:34:44.507431+08	2026-07-27 15:34:44.507431+08
20260727073444564969_3aa8bddf292c	20260727073444485987_b3282d39a33d	20260727073444399084_52737717874f	\N	human	text	Hello from B	20260727073444485987_b3282d39a33d-m2	\N	2026-07-27 15:34:44.56188+08	2026-07-27 15:34:44.56188+08
20260727074336112237_ea24aeb1f737	20260727074336085259_09db67a76e5e	20260727074335638252_bb8e3fb643a7	\N	human	text	Hello from Alice	20260727074336085259_09db67a76e5e-h1	\N	2026-07-27 15:43:36.104812+08	2026-07-27 15:43:36.104812+08
20260727074336692075_318fa579b5c6	20260727074336085259_09db67a76e5e	20260727074335793260_e1b9c7b86c93	20260727074335844815_f571a329dea1	agent	text	Reply via agent! 🤖	20260727074336085259_09db67a76e5e-a1	\N	2026-07-27 15:43:36.687962+08	2026-07-27 15:43:36.687962+08
20260727074406074949_b748f652bcd5	20260727074406052340_f5c0d66b157f	20260727074405596525_b455b43f50ea	\N	human	text	Hello from human	20260727074406052340_f5c0d66b157f-ev-h1	\N	2026-07-27 15:44:06.069213+08	2026-07-27 15:44:06.069213+08
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permissions (id, agent_id, scope, effect, resource_type, resource_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password_hash, display_name, status, created_at, updated_at) FROM stdin;
20260727072208188262_3952c32647f4	tester@agentnet.dev	$argon2id$v=19$m=65536,t=3,p=4$6V0rZQzh/L+X0tp77x3DuA$kK7HTLqCvM393M/8BgXi8KpJ595iePcnDcD9PCgaxsg	Tester	active	2026-07-27 15:22:08.065302+08	2026-07-27 15:22:08.065302+08
20260727072215363984_185b1e7c1911	tester2@agentnet.dev	$argon2id$v=19$m=65536,t=3,p=4$jvH+39ubUyqFEIIQwjhHiA$+i25c9jv8M7oAujw96MDR7xfPEPiG1MKWz2YbnGWH+Q	Tester2	active	2026-07-27 15:22:15.252104+08	2026-07-27 15:22:15.252104+08
20260727072243123281_baf52941f213	verify@agentnet.dev	$argon2id$v=19$m=65536,t=3,p=4$ICQkpJTyHuMcg7B2TiklBA$H9Ce7q0ZeY+0mgqRMkjVlrb/oXctTcLvV5XJcWst/gc	Verify User	active	2026-07-27 15:22:42.99665+08	2026-07-27 15:22:42.99665+08
20260727073212769443_120e8210a435	alice@test.dev	$argon2id$v=19$m=65536,t=3,p=4$qNV6z/mfM0ZorRXinDMGgA$nAikDZtGn8CE9iRrgs72BM9wIRM13ZEQgKj3junhFzk	Alice	active	2026-07-27 15:32:12.442071+08	2026-07-27 15:32:12.442071+08
20260727073213137096_a36e3ec76ace	bob@test.dev	$argon2id$v=19$m=65536,t=3,p=4$3ltrLSVEyLnXOsf4f2/NuQ$g9FxFSxgmMj9PPnGRbUC5wgEalFubpL9X8YB1wsZaXk	Bob	active	2026-07-27 15:32:12.896368+08	2026-07-27 15:32:12.896368+08
20260727073222930959_4994c5156150	alice2@test.dev	$argon2id$v=19$m=65536,t=3,p=4$KWVMCcE45xwjRAgBwBjjfA$pc0CIbN05ENJtT7qzKVafEma6sl5amcssKdExk97OGg	Alice2	active	2026-07-27 15:32:22.813975+08	2026-07-27 15:32:22.813975+08
20260727073223094441_9d0e62e904ee	bob2@test.dev	$argon2id$v=19$m=65536,t=3,p=4$dO5dC4HQek8ppVTqvXdujQ$cnbd9lJzPEGi3UV4xfhDJ7IzS6BANX/htwktTRaBGiQ	Bob2	active	2026-07-27 15:32:22.986271+08	2026-07-27 15:32:22.986271+08
20260727073227321166_128107110c80	a3@test.dev	$argon2id$v=19$m=65536,t=3,p=4$PaeUcs4ZQyhlTKlVSslZSw$6k8smiErzLmvxVK/vRDGU6Hqg2IbdwH6ODYupFEHaqw	A3	active	2026-07-27 15:32:27.209967+08	2026-07-27 15:32:27.209967+08
20260727073227484483_7bfeb0a24e3a	b3@test.dev	$argon2id$v=19$m=65536,t=3,p=4$fm9tTSmFkNI6J8QY4xwD4A$nGI9R79icXafD8G0+xeHzYuRhvMrxI0nn2ngGY2DsGM	B3	active	2026-07-27 15:32:27.339062+08	2026-07-27 15:32:27.339062+08
20260727073254242091_cc15a2325b2a	x@x.dev	$argon2id$v=19$m=65536,t=3,p=4$QYhRqtV6b835X0vJWSvFmA$xDWvJmqMw8xEjopcRlPAFQEnOin2VfMQO5XKsEXIxFw	X	active	2026-07-27 15:32:54.131161+08	2026-07-27 15:32:54.131161+08
20260727073254396052_afdbd24cadf5	y@y.dev	$argon2id$v=19$m=65536,t=3,p=4$bu29FyIEQEjJGWMsxXhPiQ$H+lYY9ch4Dwk2IlAp1lihU87/GaKR142pswhff6+BsI	Y	active	2026-07-27 15:32:54.289244+08	2026-07-27 15:32:54.289244+08
20260727073259701808_8698ae6ea42b	aa@test.dev	$argon2id$v=19$m=65536,t=3,p=4$5JyTEmLMWYsxphTCOIcQwg$DzYnUG/gUcZWftXAH0+E7MCVOXgbpBzPCpkaDafpFg8	AA	active	2026-07-27 15:32:59.593694+08	2026-07-27 15:32:59.593694+08
20260727073259858027_541e21b69498	bb@test.dev	$argon2id$v=19$m=65536,t=3,p=4$SmntvXduDaGUUirFeI/xHg$yZRCzMq4nCt/Rrhqxf1YpwrDmklDbRQEK8jbwa/7ji8	BB	active	2026-07-27 15:32:59.750442+08	2026-07-27 15:32:59.750442+08
20260727073444252237_07de0b96f196	p1@test.dev	$argon2id$v=19$m=65536,t=3,p=4$bW3t/R8DYGztvRfiHEPoXQ$VCRv450Q0CPeAk7BKxVvpFpbVF1YB/Dlelqmvk7bswA	P1	active	2026-07-27 15:34:44.124282+08	2026-07-27 15:34:44.124282+08
20260727073444399084_52737717874f	p2@test.dev	$argon2id$v=19$m=65536,t=3,p=4$S0kpReg951xL6X3PGWOMEQ$QpXKXrmxUV33l6vsuiesjDNS7K7ZpP1Ty+p96KtTwrI	P2	active	2026-07-27 15:34:44.285434+08	2026-07-27 15:34:44.285434+08
20260727074322644413_82b289b0767f	agent_e2e_a@test.dev	$argon2id$v=19$m=65536,t=3,p=4$Z2zt3VtLifGeU0rp3ftfSw$roHR97dbgu+wmCS/S8GUsJrwIQFqRPt6u6AnBjDPdrI	AgentE2E-A	active	2026-07-27 15:43:22.521214+08	2026-07-27 15:43:22.521214+08
20260727074322898797_6467e242a824	agent_e2e_b@test.dev	$argon2id$v=19$m=65536,t=3,p=4$Q8gZA4BwjjGGsDaGEELI+Q$Ww5RzSDHuHxQY40JD0retSlvwVnqECP0Dq2fOzJs22w	AgentE2E-B	active	2026-07-27 15:43:22.793254+08	2026-07-27 15:43:22.793254+08
20260727074335638252_bb8e3fb643a7	sp3a@test.dev	$argon2id$v=19$m=65536,t=3,p=4$yLk3Rqg15lxrjRGidC4FQA$xNyG9B7vIBkWBlcl2v2O4HBfZlx53eVg/7c/fY7NGCc	SP3A	active	2026-07-27 15:43:35.535292+08	2026-07-27 15:43:35.535292+08
20260727074335793260_e1b9c7b86c93	sp3b@test.dev	$argon2id$v=19$m=65536,t=3,p=4$JIQQwnjvvTcG4JzTOofQug$1ZcxSXsEeHR+2dXGHd03x4aLwLu/2urJlN9cTj7S3CY	SP3B	active	2026-07-27 15:43:35.685828+08	2026-07-27 15:43:35.685828+08
20260727074405596525_b455b43f50ea	ev@test.dev	$argon2id$v=19$m=65536,t=3,p=4$RSjFOIdw7v0fgxAihDAmxA$y9DKDER81KPv37jd/87clfbpnlPeePBag7Aq04MeCUU	EvA	active	2026-07-27 15:44:05.488165+08	2026-07-27 15:44:05.488165+08
20260727074405775883_69f6ee1765da	evb@test.dev	$argon2id$v=19$m=65536,t=3,p=4$KKUUYmxtLaXU2nvv3fv/Xw$gS2jduN63OXAhQKHLztxNcCyqx6kEhS1yGkrGXDtufQ	EvB	active	2026-07-27 15:44:05.667473+08	2026-07-27 15:44:05.667473+08
\.


--
-- Name: agent_conversation_acls agent_conversation_acls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_conversation_acls
    ADD CONSTRAINT agent_conversation_acls_pkey PRIMARY KEY (id);


--
-- Name: agent_credentials agent_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_credentials
    ADD CONSTRAINT agent_credentials_pkey PRIMARY KEY (id);


--
-- Name: agent_events agent_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_events
    ADD CONSTRAINT agent_events_pkey PRIMARY KEY (id);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: conversation_members conversation_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_members
    ADD CONSTRAINT conversation_members_pkey PRIMARY KEY (id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_agent_conversation_acls_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_conversation_acls_agent_id ON public.agent_conversation_acls USING btree (agent_id);


--
-- Name: ix_agent_conversation_acls_conversation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_conversation_acls_conversation_id ON public.agent_conversation_acls USING btree (conversation_id);


--
-- Name: ix_agent_credentials_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_credentials_agent_id ON public.agent_credentials USING btree (agent_id);


--
-- Name: ix_agent_credentials_prefix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_credentials_prefix ON public.agent_credentials USING btree (prefix);


--
-- Name: ix_agent_events_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agent_events_agent_id ON public.agent_events USING btree (agent_id);


--
-- Name: ix_agents_handle; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_agents_handle ON public.agents USING btree (handle);


--
-- Name: ix_agents_owner_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_agents_owner_user_id ON public.agents USING btree (owner_user_id);


--
-- Name: ix_audit_logs_owner_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_owner_user_id ON public.audit_logs USING btree (owner_user_id);


--
-- Name: ix_contacts_addressee_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_contacts_addressee_user_id ON public.contacts USING btree (addressee_user_id);


--
-- Name: ix_contacts_requester_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_contacts_requester_user_id ON public.contacts USING btree (requester_user_id);


--
-- Name: ix_conversation_members_conversation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_conversation_members_conversation_id ON public.conversation_members USING btree (conversation_id);


--
-- Name: ix_conversation_members_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_conversation_members_user_id ON public.conversation_members USING btree (user_id);


--
-- Name: ix_messages_client_message_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_messages_client_message_id ON public.messages USING btree (client_message_id);


--
-- Name: ix_messages_conversation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_messages_conversation_id ON public.messages USING btree (conversation_id);


--
-- Name: ix_permissions_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_permissions_agent_id ON public.permissions USING btree (agent_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: agent_conversation_acls agent_conversation_acls_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_conversation_acls
    ADD CONSTRAINT agent_conversation_acls_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: agent_conversation_acls agent_conversation_acls_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_conversation_acls
    ADD CONSTRAINT agent_conversation_acls_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id);


--
-- Name: agent_conversation_acls agent_conversation_acls_granted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_conversation_acls
    ADD CONSTRAINT agent_conversation_acls_granted_by_fkey FOREIGN KEY (granted_by) REFERENCES public.users(id);


--
-- Name: agent_credentials agent_credentials_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_credentials
    ADD CONSTRAINT agent_credentials_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: agent_events agent_events_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_events
    ADD CONSTRAINT agent_events_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: agents agents_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.users(id);


--
-- Name: audit_logs audit_logs_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.users(id);


--
-- Name: contacts contacts_addressee_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_addressee_user_id_fkey FOREIGN KEY (addressee_user_id) REFERENCES public.users(id);


--
-- Name: contacts contacts_requester_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_requester_user_id_fkey FOREIGN KEY (requester_user_id) REFERENCES public.users(id);


--
-- Name: conversation_members conversation_members_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_members
    ADD CONSTRAINT conversation_members_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id);


--
-- Name: conversation_members conversation_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_members
    ADD CONSTRAINT conversation_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: conversations conversations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: messages messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id);


--
-- Name: messages messages_sender_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_sender_user_id_fkey FOREIGN KEY (sender_user_id) REFERENCES public.users(id);


--
-- Name: permissions permissions_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- PostgreSQL database dump complete
--

\unrestrict PVT2X2fEdwa76gt2R9yZ0KEZM5bQj7SeeZBLAWcqjtmRZthHQnQfAcWL16Sbk0a

